import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Trophy, Calendar, Users, ChevronRight, Star, Clock, MapPin, Tv, Menu, X } from 'lucide-react';

// Player images
const playerImages = [
  'https://image.qwenlm.ai/generated-images/7ad90540-b109-4b2c-9a51-305151769478/_result.png',
  'https://image.qwenlm.ai/generated-images/4c763285-a4d1-49a0-befe-9bafbbc00419/_result.png',
  'https://image.qwenlm.ai/generated-images/5c3fa8b8-0505-4900-81fb-ba884bce4c18/_result.png',
  'https://image.qwenlm.ai/generated-images/17387b79-5d86-42db-b585-7149940fad50/_result.png',
  'https://image.qwenlm.ai/generated-images/5cea14b8-402d-4499-bd44-de04c1be83d8/_result.png',
];

const heroImage = 'https://image.qwenlm.ai/generated-images/c9730cf2-5958-4250-9d38-075d28494ab3/_result.png';

// Team data
const teams = [
  { rank: 1, name: 'ECHO PH', wins: 12, losses: 2, points: 12, logo: '🔥', color: 'from-red-600 to-orange-500' },
  { rank: 2, name: 'AP Bren', wins: 11, losses: 3, points: 11, logo: '🐻', color: 'from-amber-600 to-yellow-500' },
  { rank: 3, name: 'ONIC PH', wins: 10, losses: 4, points: 10, logo: '🦅', color: 'from-green-600 to-emerald-500' },
  { rank: 4, name: 'Team Liquid PH', wins: 9, losses: 5, points: 9, logo: '💧', color: 'from-blue-600 to-cyan-500' },
  { rank: 5, name: 'Elevate', wins: 7, losses: 7, points: 7, logo: '⚡', color: 'from-purple-600 to-violet-500' },
  { rank: 6, name: 'Aurora', wins: 6, losses: 8, points: 6, logo: '🌌', color: 'from-indigo-600 to-blue-500' },
  { rank: 7, name: 'TNC Pro', wins: 5, losses: 9, points: 5, logo: '🎯', color: 'from-pink-600 to-rose-500' },
  { rank: 8, name: 'Omega Esports', wins: 3, losses: 11, points: 3, logo: '🛡️', color: 'from-gray-600 to-slate-500' },
];

// Players data
const players = [
  { id: 1, name: 'KarlTzy', team: 'ECHO PH', role: 'Jungler', image: playerImages[0], kda: '8.5', mvp: 5, imageIndex: 0 },
  { id: 2, name: 'Super Frince', team: 'AP Bren', role: 'Exp Lane', image: playerImages[1], kda: '7.2', mvp: 4, imageIndex: 1 },
  { id: 3, name: "D'Xavier", team: 'ONIC PH', role: 'Gold Lane', image: playerImages[2], kda: '9.1', mvp: 6, imageIndex: 2 },
  { id: 4, name: 'Yawi', team: 'Team Liquid PH', role: 'Mid Lane', image: playerImages[3], kda: '7.8', mvp: 3, imageIndex: 3 },
  { id: 5, name: 'OhMyV3NNUS', team: 'Elevate', role: 'Roamer', image: playerImages[4], kda: '6.9', mvp: 2, imageIndex: 4 },
];

// Schedule data
const matches = [
  { id: 1, team1: 'ECHO PH', team2: 'AP Bren', date: 'Jan 25, 2025', time: '5:00 PM', venue: 'SM Mall of Asia Arena', status: 'upcoming' },
  { id: 2, team1: 'ONIC PH', team2: 'Team Liquid PH', date: 'Jan 25, 2025', time: '7:30 PM', venue: 'SM Mall of Asia Arena', status: 'upcoming' },
  { id: 3, team1: 'Elevate', team2: 'Aurora', date: 'Jan 26, 2025', time: '3:00 PM', venue: 'Ynares Center', status: 'upcoming' },
  { id: 4, team1: 'TNC Pro', team2: 'Omega Esports', date: 'Jan 26, 2025', time: '5:30 PM', venue: 'Ynares Center', status: 'upcoming' },
  { id: 5, team1: 'ECHO PH', team2: 'ONIC PH', date: 'Jan 27, 2025', time: '5:00 PM', venue: 'SM Mall of Asia Arena', status: 'upcoming' },
];

// News data
const news = [
  { id: 1, title: 'ECHO PH Dominates Week 7 with Perfect Record', date: 'Jan 22, 2025', category: 'Match Results', excerpt: 'ECHO PH continues their dominant run in MPL PH Season 14 with another clean sweep...' },
  { id: 2, title: 'D\'Xavier Wins MVP of the Week', date: 'Jan 21, 2025', category: 'Awards', excerpt: 'ONIC PH\'s gold laner D\'Xavier takes home the MVP award after an outstanding performance...' },
  { id: 3, title: 'Playoffs Schedule Announced', date: 'Jan 20, 2025', category: 'Announcement', excerpt: 'The MPL PH Season 14 playoffs schedule has been officially announced. Top 6 teams will compete...' },
  { id: 4, title: 'New Patch Changes Meta Significantly', date: 'Jan 19, 2025', category: 'Game Update', excerpt: 'The latest patch brings major changes to the hero pool and team compositions...' },
];

function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'glass-effect shadow-lg' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-neon-blue to-neon-purple flex items-center justify-center font-bold text-white text-lg">
              M
            </div>
            <span className="text-white font-bold text-xl tracking-wider">MPL <span className="text-neon-blue">PH</span></span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <a href="#home" className="text-white/80 hover:text-neon-blue transition-colors font-medium">Home</a>
            <a href="#standings" className="text-white/80 hover:text-neon-blue transition-colors font-medium">Standings</a>
            <a href="#players" className="text-white/80 hover:text-neon-blue transition-colors font-medium">Players</a>
            <a href="#schedule" className="text-white/80 hover:text-neon-blue transition-colors font-medium">Schedule</a>
            <a href="#news" className="text-white/80 hover:text-neon-blue transition-colors font-medium">News</a>
            <button className="px-4 py-2 bg-gradient-to-r from-neon-blue to-neon-purple rounded-lg text-white font-medium hover:opacity-90 transition-opacity">
              Watch Live
            </button>
          </div>

          <button className="md:hidden text-white" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden glass-effect border-t border-white/10">
          <div className="px-4 py-4 space-y-3">
            <a href="#home" className="block text-white/80 hover:text-neon-blue py-2">Home</a>
            <a href="#standings" className="block text-white/80 hover:text-neon-blue py-2">Standings</a>
            <a href="#players" className="block text-white/80 hover:text-neon-blue py-2">Players</a>
            <a href="#schedule" className="block text-white/80 hover:text-neon-blue py-2">Schedule</a>
            <a href="#news" className="block text-white/80 hover:text-neon-blue py-2">News</a>
            <button className="w-full px-4 py-2 bg-gradient-to-r from-neon-blue to-neon-purple rounded-lg text-white font-medium">
              Watch Live
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}

function HeroSection() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img src={heroImage} alt="Esports Arena" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-dark/70 via-dark/50 to-dark"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-dark/80 via-transparent to-dark/80"></div>
      </div>

      {/* Animated particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-neon-blue/30 rounded-full animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${3 + Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="inline-flex items-center px-4 py-2 rounded-full glass-effect mb-6 animate-pulse-border">
            <Tv size={16} className="text-neon-blue mr-2" />
            <span className="text-neon-blue text-sm font-medium">LIVE NOW • Season 14</span>
          </div>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-5xl md:text-7xl lg:text-8xl font-black text-white mb-4 tracking-tight"
        >
          MPL <span className="gradient-text">PH</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-xl md:text-2xl text-white/70 mb-8 max-w-2xl mx-auto"
        >
          Mobile Legends: Bang Bang Professional League Philippines
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <button className="px-8 py-4 bg-gradient-to-r from-neon-blue to-neon-purple rounded-xl text-white font-bold text-lg hover:opacity-90 transition-all hover:scale-105 shadow-lg shadow-neon-blue/20">
            Watch Live Stream
          </button>
          <button className="px-8 py-4 border border-white/30 rounded-xl text-white font-bold text-lg hover:bg-white/10 transition-all">
            View Schedule
          </button>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="grid grid-cols-3 gap-8 mt-16 max-w-lg mx-auto"
        >
          <div className="text-center">
            <div className="text-3xl font-bold text-neon-blue">8</div>
            <div className="text-white/50 text-sm">Teams</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-neon-blue">56</div>
            <div className="text-white/50 text-sm">Players</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-neon-blue">14</div>
            <div className="text-white/50 text-sm">Season</div>
          </div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 rounded-full border-2 border-white/30 flex items-start justify-center p-2">
          <div className="w-1 h-3 bg-neon-blue rounded-full"></div>
        </div>
      </div>
    </section>
  );
}

function StandingsSection() {
  return (
    <section id="standings" className="py-20 px-4 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-dark via-secondary/20 to-dark"></div>
      <div className="max-w-6xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center px-3 py-1 rounded-full bg-neon-blue/10 border border-neon-blue/30 mb-4">
            <Trophy size={14} className="text-neon-blue mr-2" />
            <span className="text-neon-blue text-sm">Season 14 Standings</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Team <span className="gradient-text">Standings</span></h2>
          <p className="text-white/50 max-w-xl mx-auto">Current rankings based on wins and points accumulated throughout the regular season.</p>
        </motion.div>

        <div className="grid gap-3">
          {teams.map((team, index) => (
            <motion.div
              key={team.rank}
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`glass-effect rounded-xl p-4 flex items-center justify-between card-hover ${team.rank <= 3 ? 'neon-border' : ''}`}
            >
              <div className="flex items-center space-x-4">
                <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${team.color} flex items-center justify-center text-xl`}>
                  {team.logo}
                </div>
                <div>
                  <h3 className="text-white font-bold text-lg">{team.name}</h3>
                  <p className="text-white/40 text-sm">{team.wins}W - {team.losses}L</p>
                </div>
              </div>
              <div className="flex items-center space-x-6">
                <div className="hidden sm:block text-center">
                  <div className="text-white font-bold">{team.points}</div>
                  <div className="text-white/40 text-xs">Points</div>
                </div>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                  team.rank === 1 ? 'bg-yellow-500/20 text-yellow-400' :
                  team.rank === 2 ? 'bg-gray-300/20 text-gray-300' :
                  team.rank === 3 ? 'bg-amber-700/20 text-amber-600' :
                  'bg-white/5 text-white/50'
                }`}>
                  {team.rank}
                </div>
                <ChevronRight size={20} className="text-white/30" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function PlayersSection() {
  const [selectedPlayer, setSelectedPlayer] = useState(0);

  return (
    <section id="players" className="py-20 px-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-dark via-primary/30 to-dark"></div>
      
      {/* Background decoration */}
      <div className="absolute top-20 right-0 w-96 h-96 bg-neon-blue/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 left-0 w-96 h-96 bg-neon-purple/5 rounded-full blur-3xl"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center px-3 py-1 rounded-full bg-neon-purple/10 border border-neon-purple/30 mb-4">
            <Users size={14} className="text-neon-purple mr-2" />
            <span className="text-neon-purple text-sm">Star Players</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Featured <span className="gradient-text">Players</span></h2>
          <p className="text-white/50 max-w-xl mx-auto">Meet the top performers of MPL PH Season 14.</p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 items-center">
          {/* Player Card */}
          <motion.div
            key={selectedPlayer}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
            className="relative"
          >
            <div className="glass-effect rounded-2xl overflow-hidden neon-border">
              <div className="relative h-96 overflow-hidden">
                <img
                  src={players[selectedPlayer].image}
                  alt={players[selectedPlayer].name}
                  className="w-full h-full object-cover object-top"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark via-dark/30 to-transparent"></div>
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="px-2 py-1 bg-neon-blue/20 rounded text-neon-blue text-xs font-medium">
                      {players[selectedPlayer].role}
                    </span>
                    <span className="px-2 py-1 bg-white/10 rounded text-white/70 text-xs font-medium">
                      {players[selectedPlayer].team}
                    </span>
                  </div>
                  <h3 className="text-3xl font-bold text-white">{players[selectedPlayer].name}</h3>
                </div>
              </div>
              
              {/* Player Stats */}
              <div className="p-6 grid grid-cols-2 gap-4">
                <div className="bg-white/5 rounded-xl p-4 text-center">
                  <div className="text-2xl font-bold text-neon-blue">{players[selectedPlayer].kda}</div>
                  <div className="text-white/40 text-sm">Avg. KDA</div>
                </div>
                <div className="bg-white/5 rounded-xl p-4 text-center">
                  <div className="text-2xl font-bold text-gold">{players[selectedPlayer].mvp}</div>
                  <div className="text-white/40 text-sm">MVP Awards</div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Player List */}
          <div className="space-y-3">
            {players.map((player, index) => (
              <motion.button
                key={player.id}
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                onClick={() => setSelectedPlayer(index)}
                className={`w-full flex items-center space-x-4 p-4 rounded-xl transition-all ${
                  selectedPlayer === index
                    ? 'glass-effect neon-border shadow-lg shadow-neon-blue/10'
                    : 'bg-white/5 hover:bg-white/10'
                }`}
              >
                <div className="w-14 h-14 rounded-xl overflow-hidden flex-shrink-0">
                  <img src={player.image} alt={player.name} className="w-full h-full object-cover object-top" />
                </div>
                <div className="flex-1 text-left">
                  <h4 className="text-white font-bold">{player.name}</h4>
                  <p className="text-white/40 text-sm">{player.team} • {player.role}</p>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="text-right">
                    <div className="text-neon-blue font-bold text-sm">KDA {player.kda}</div>
                    <div className="text-gold text-xs">{player.mvp} MVP</div>
                  </div>
                  {selectedPlayer === index && (
                    <div className="w-2 h-2 rounded-full bg-neon-blue animate-pulse"></div>
                  )}
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function ScheduleSection() {
  return (
    <section id="schedule" className="py-20 px-4 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-dark via-secondary/10 to-dark"></div>
      <div className="max-w-4xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center px-3 py-1 rounded-full bg-gold/10 border border-gold/30 mb-4">
            <Calendar size={14} className="text-gold mr-2" />
            <span className="text-gold text-sm">Match Schedule</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Upcoming <span className="gradient-text">Matches</span></h2>
          <p className="text-white/50 max-w-xl mx-auto">Don't miss the exciting matchups this week!</p>
        </motion.div>

        <div className="space-y-4">
          {matches.map((match, index) => (
            <motion.div
              key={match.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="glass-effect rounded-xl p-6 card-hover neon-border"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                {/* Teams */}
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center text-white font-bold text-sm">
                      {match.team1.charAt(0)}
                    </div>
                    <span className="text-white font-bold">{match.team1}</span>
                  </div>
                  <div className="px-3 py-1 bg-accent/20 rounded-lg">
                    <span className="text-accent font-bold text-sm">VS</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center text-white font-bold text-sm">
                      {match.team2.charAt(0)}
                    </div>
                    <span className="text-white font-bold">{match.team2}</span>
                  </div>
                </div>

                {/* Match Info */}
                <div className="flex items-center space-x-6 text-sm">
                  <div className="flex items-center space-x-2 text-white/50">
                    <Clock size={14} />
                    <span>{match.time}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-white/50">
                    <Calendar size={14} />
                    <span>{match.date}</span>
                  </div>
                  <div className="hidden lg:flex items-center space-x-2 text-white/50">
                    <MapPin size={14} />
                    <span>{match.venue}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="text-center mt-8">
          <button className="px-6 py-3 border border-neon-blue/30 rounded-xl text-neon-blue font-medium hover:bg-neon-blue/10 transition-all">
            View Full Schedule <ChevronRight size={16} className="inline ml-1" />
          </button>
        </div>
      </div>
    </section>
  );
}

function NewsSection() {
  return (
    <section id="news" className="py-20 px-4 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-dark via-primary/20 to-dark"></div>
      <div className="max-w-6xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center px-3 py-1 rounded-full bg-accent/10 border border-accent/30 mb-4">
            <Star size={14} className="text-accent mr-2" />
            <span className="text-accent text-sm">Latest Updates</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Latest <span className="gradient-text">News</span></h2>
          <p className="text-white/50 max-w-xl mx-auto">Stay updated with the latest happenings in MPL PH.</p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6">
          {news.map((item, index) => (
            <motion.article
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="glass-effect rounded-xl overflow-hidden card-hover group cursor-pointer"
            >
              <div className="p-6">
                <div className="flex items-center space-x-3 mb-3">
                  <span className="px-2 py-1 bg-neon-blue/10 rounded text-neon-blue text-xs font-medium">
                    {item.category}
                  </span>
                  <span className="text-white/30 text-xs">{item.date}</span>
                </div>
                <h3 className="text-white font-bold text-lg mb-2 group-hover:text-neon-blue transition-colors">
                  {item.title}
                </h3>
                <p className="text-white/40 text-sm leading-relaxed">{item.excerpt}</p>
                <div className="mt-4 flex items-center text-neon-blue text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                  Read More <ChevronRight size={14} className="ml-1" />
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="relative py-16 px-4 border-t border-white/5">
      <div className="absolute inset-0 bg-gradient-to-t from-primary/50 to-dark"></div>
      <div className="max-w-6xl mx-auto relative z-10">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          <div className="md:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-neon-blue to-neon-purple flex items-center justify-center font-bold text-white text-lg">
                M
              </div>
              <span className="text-white font-bold text-xl">MPL <span className="text-neon-blue">PH</span></span>
            </div>
            <p className="text-white/40 text-sm leading-relaxed">
              The premier Mobile Legends: Bang Bang professional league in the Philippines.
            </p>
          </div>
          
          <div>
            <h4 className="text-white font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-white/40 hover:text-neon-blue transition-colors text-sm">Home</a></li>
              <li><a href="#" className="text-white/40 hover:text-neon-blue transition-colors text-sm">Standings</a></li>
              <li><a href="#" className="text-white/40 hover:text-neon-blue transition-colors text-sm">Schedule</a></li>
              <li><a href="#" className="text-white/40 hover:text-neon-blue transition-colors text-sm">Teams</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4">Follow Us</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-white/40 hover:text-neon-blue transition-colors text-sm">Facebook</a></li>
              <li><a href="#" className="text-white/40 hover:text-neon-blue transition-colors text-sm">Twitter</a></li>
              <li><a href="#" className="text-white/40 hover:text-neon-blue transition-colors text-sm">Instagram</a></li>
              <li><a href="#" className="text-white/40 hover:text-neon-blue transition-colors text-sm">YouTube</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4">Watch</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-white/40 hover:text-neon-blue transition-colors text-sm">Facebook Live</a></li>
              <li><a href="#" className="text-white/40 hover:text-neon-blue transition-colors text-sm">YouTube Live</a></li>
              <li><a href="#" className="text-white/40 hover:text-neon-blue transition-colors text-sm">Twitch</a></li>
              <li><a href="#" className="text-white/40 hover:text-neon-blue transition-colors text-sm">TikTok</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-white/30 text-sm">© 2025 MPL PH. All rights reserved.</p>
          <p className="text-white/30 text-sm mt-2 md:mt-0">Mobile Legends: Bang Bang Professional League Philippines</p>
        </div>
      </div>
    </footer>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-dark text-white overflow-x-hidden">
      <Navbar />
      <HeroSection />
      <StandingsSection />
      <PlayersSection />
      <ScheduleSection />
      <NewsSection />
      <Footer />
    </div>
  );
}
